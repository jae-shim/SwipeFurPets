package testing;
public class Match {
	
    private String email;
    private Integer petID;
    
    public Match(String email, Integer petID) {
        this.email = email;
        this.petID = petID;
    }
}
