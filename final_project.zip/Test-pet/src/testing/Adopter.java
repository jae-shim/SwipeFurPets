package testing;
public class Adopter {
    private String fName;
    private String lName;
    private String email;
    private String password;
    private String phone;
    private Integer zip;
    public Adopter(String fName, String lName, String email, String password, String phone, Integer zip) {
        this.fName = fName;
        this.lName = lName;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.zip = zip;
    }
}
